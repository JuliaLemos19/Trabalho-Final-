import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class CadastroAcademia {

    // Definindo a URL do banco de dados SQLite
    private static final String DATABASE_URL = "jdbc:sqlite:C:/Users/aluno/Downloads/TP Final/TP Final/sqlite3.db";

    public static void main(String[] args) {
        // Criando os componentes da interface
        JFrame frame = new JFrame("Cadastro de Alunos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.setSize(400, 300);
        frame.setLayout(new GridLayout(7, 2));
		
        // Campos de texto para entrada de dados
        JTextField nomeField = new JTextField(20);
        JTextField idadeField = new JTextField(20);
        JTextField pesoField = new JTextField(20);
        JTextField alturaField = new JTextField(20);
        JTextField objetivoField = new JTextField(20);

        // Botões
        JButton cadastrarButton = new JButton("Incluir");
        JButton limparButton = new JButton("Limpar");
        JButton apresentarButton = new JButton("Apresentar Dados");
        JButton sairButton = new JButton("Sair");

        // Adicionando os componentes à janela
        frame.add(new JLabel("Nome:"));
        frame.add(nomeField);
        frame.add(new JLabel("Idade:"));
        frame.add(idadeField);
        frame.add(new JLabel("Peso:"));
        frame.add(pesoField);
        frame.add(new JLabel("Altura:"));
        frame.add(alturaField);
        frame.add(new JLabel("Objetivo:"));
        frame.add(objetivoField);
        frame.add(cadastrarButton);
        frame.add(limparButton);
        frame.add(apresentarButton);
        frame.add(sairButton);

        // Criação do banco de dados e tabela se não existirem
        criarTabela();

        // Ação do botão "Cadastrar"
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String idade = idadeField.getText();
                String peso = pesoField.getText();
                String altura = alturaField.getText();
                String objetivo = objetivoField.getText();

                // Inserir dados no banco de dados
                try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
                    String sql = "INSERT INTO alunos (nome, idade, peso, altura, objetivo) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, nome);
                    statement.setInt(2, Integer.parseInt(idade));
                    statement.setFloat(3, Float.parseFloat(peso));
                    statement.setFloat(4, Float.parseFloat(altura));
                    statement.setString(5, objetivo);
                    statement.executeUpdate();
                    JOptionPane.showMessageDialog(frame, "Dados incluídos no banco de dados com sucesso!");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Erro ao incluir dados: " + ex.getMessage());
                }
            }
        });

        // Ação do botão "Limpar"
        limparButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nomeField.setText("");
                idadeField.setText("");
                pesoField.setText("");
                alturaField.setText("");
                objetivoField.setText("");
            }
        });

        // Ação do botão "Apresentar Dados"
        apresentarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dados = "Nome: " + nomeField.getText() +
                        "\nIdade: " + idadeField.getText() +
                        "\nPeso: " + pesoField.getText() +
                        "\nAltura: " + alturaField.getText() +
                        "\nObjetivo: " + objetivoField.getText();
                JOptionPane.showMessageDialog(frame, dados);
            }
        });

        // Ação do botão "Sair"
        sairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Tornar a janela visível
        frame.setVisible(true);
    }

    // Método para criar a tabela no banco de dados caso não exista
    private static void criarTabela() {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String sql = "CREATE TABLE IF NOT EXISTS alunos (" +
                         "nome TEXT," +
                         "idade INTEGER," +
                         "peso REAL," +
                         "altura REAL," +
                         "objetivo TEXT" +
                         ");";
            Statement statement = connection.createStatement();
            statement.execute(sql);
        } catch (SQLException e) {
            System.out.println("Erro ao criar a tabela: " + e.getMessage());
        }
    }
}
